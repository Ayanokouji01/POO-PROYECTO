
package Metodos;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class ventanaFlotante {
private String ruta="/imagenes/Final.png";
private int width=50;
private int height=50;

    
     public Icon icono(String url,int width,int height){//rETORNO LA IMAGEN
        Icon img=new ImageIcon(new ImageIcon(getClass().getResource(url)).getImage()
                .getScaledInstance(width,height,java.awt.Image.SCALE_SMOOTH));
        
        return img;
  
    }
    public void imprimir(String texto,String titulo, int width,int height){
        JOptionPane.showMessageDialog(null, texto, titulo,
                JOptionPane.PLAIN_MESSAGE, icono(ruta, width, height));
    }
    
//     public String imprimir(String texto,String titulo, int width,int height){
//        JOptionPane.showInputDialog(null, texto, titulo,
//                JOptionPane.PLAIN_MESSAGE, icono(ruta, width, height));
//        
//    }
//    
    

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    
}   
    

