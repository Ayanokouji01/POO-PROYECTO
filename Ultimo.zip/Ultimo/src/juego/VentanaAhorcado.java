/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;

import Metodos.ventanaFlotante;
import java.beans.PropertyVetoException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class VentanaAhorcado extends javax.swing.JInternalFrame {
    ventanaFlotante metodos
            = new ventanaFlotante();
    String palabrasAdivinar[];
    String Pista;
    char[] palabraActiva;
    char[] palabraOculta;
    String letraAux;
    char letraChar;
    int cuentaLabel = 0;

    /**
     * Creates new form VentanaAhorcado
     */
    public VentanaAhorcado() {
        String comprobar="",comprobar2="";
        try{
            while (comprobar.equals("")) {                
                String Adivinar=JOptionPane.showInputDialog(null,"Ingrese palabra a adivinar ");
                Pista=JOptionPane.showInputDialog(null , "Pista de la palabra a Adivinar (Especificar si es mayucusla o minuscula)", 3);
                comprobar=Adivinar;
                comprobar2=Pista;
                if(comprobar.equals("")){
                    metodos.imprimir("No se detecto valor en la palabra a adivinar\nPor favor intete nuevamente", "Error", 50, 50);
                }
                palabrasAdivinar = new String[5]; 
                palabrasAdivinar[0] = Adivinar;
                
            }
            if(comprobar2.equals("")){
                Pista="No hay pistas disponibles";
            }

                
        palabraActiva = palabrasAdivinar[0].toCharArray(); // carga la palabra separando caracteres dentro del String
        palabraOculta = palabrasAdivinar[0].toCharArray();// carga la palabra separando caracteres dentro del String
        
        for (int pos = 0; pos < palabraOculta.length; pos++) {  //cargar un arreglo con guiones q representa la palabra oculta 
            palabraOculta[pos] = '-';
        }
            initComponents();
        try {
            setMaximum(true);
        } catch (PropertyVetoException ex) {
            Logger.getLogger(VentanaAhorcado.class.getName()).log(Level.SEVERE, null, ex);
        }
            ocultarDibujo();
        }catch(java.lang.NullPointerException ex){
            metodos.imprimir("Ahorcado no instanceado","Error", 50, 50);
        }    
        
    }

    public void ocultarDibujo() {
        this.jLabel1.setVisible(false);
        this.jLabel2.setVisible(false);
        this.jLabel3.setVisible(false);
        this.felicidades.setVisible(false);
        this.winner.setVisible(false);
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelAhorcado = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        winner = new javax.swing.JLabel();
        felicidades = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        txtPalabraAdivinar = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        txtTurno = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        itemReiniciar = new javax.swing.JMenuItem();
        itemFondo = new javax.swing.JMenuItem();
        itemSonido = new javax.swing.JMenuItem();
        itemSalir = new javax.swing.JMenuItem();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Juego del Ahorcado");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelAhorcado.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cabeza.png"))); // NOI18N
        jLabel3.setText("CABEZA");
        jLabel3.setToolTipText("");
        PanelAhorcado.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 10, 260, 240));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cuerpo.png"))); // NOI18N
        jLabel1.setText("CUERPO");
        PanelAhorcado.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 220, 260, 260));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Piernas.png"))); // NOI18N
        PanelAhorcado.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 450, 270, 420));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 0, 0));
        jButton3.setText("PISTA");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        PanelAhorcado.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 110, 120, 80));

        winner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gif/winner.gif"))); // NOI18N
        PanelAhorcado.add(winner, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 510, 350));

        felicidades.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gif/FELICIDADES.gif"))); // NOI18N
        felicidades.setText("felicidades");
        PanelAhorcado.add(felicidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 210, 400, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton2.setText("Cerrar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        PanelAhorcado.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 150, -1, -1));

        jLabel8.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        PanelAhorcado.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 279, 251, 27));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Validar Letra");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setSelected(true);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        PanelAhorcado.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, -1, -1));

        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        PanelAhorcado.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 53, 37));

        txtPalabraAdivinar.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtPalabraAdivinar.setForeground(new java.awt.Color(204, 0, 0));
        txtPalabraAdivinar.setText("Palabra a Adivinar");
        txtPalabraAdivinar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtPalabraAdivinar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPalabraAdivinarMouseClicked(evt);
            }
        });
        PanelAhorcado.add(txtPalabraAdivinar, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 65, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 0));
        jLabel6.setText("Digite letra");
        jLabel6.setToolTipText("");
        PanelAhorcado.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        jTextField1.setEditable(false);
        jTextField1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(204, 0, 0));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        PanelAhorcado.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, 347, -1));

        txtTurno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTurno.setText("Turno ");
        PanelAhorcado.add(txtTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 60, 90, -1));

        jLabel4.setText("Jugador 1:");
        PanelAhorcado.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        jLabel5.setText("Jugador 2:");
        PanelAhorcado.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 20, -1, -1));

        getContentPane().add(PanelAhorcado, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1520, 900));

        jMenu1.setText("Opciones");

        itemReiniciar.setText("Reiniciar ");
        itemReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemReiniciarActionPerformed(evt);
            }
        });
        jMenu1.add(itemReiniciar);

        itemFondo.setText("Fondo");
        jMenu1.add(itemFondo);

        itemSonido.setText("Sonido");
        itemSonido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSonidoActionPerformed(evt);
            }
        });
        jMenu1.add(itemSonido);

        itemSalir.setText("Salir");
        itemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSalirActionPerformed(evt);
            }
        });
        jMenu1.add(itemSalir);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // aca de valida si la letra esta en el arreglo
        boolean acerto = false;
        try{
        letraAux = this.jTextField2.getText().trim();
        letraChar = letraAux.charAt(0);
        for (int pos = 0; pos < palabraActiva.length; pos++) { //cargar un arreglo con guiones q representa la palabra oculta 
            if (palabraActiva[pos] == letraChar) {
                palabraOculta[pos] = palabraActiva[pos];
                acerto = true;
            }
        }
        }catch(java.lang.StringIndexOutOfBoundsException ex){
            metodos.imprimir("Texto vacio, por favor digite un carater", "Error, null", 55, 55);
        }
        this.jTextField1.setText(String.valueOf(palabraOculta));
        if (acerto == false) {
            cuentaLabel++;
            switch (cuentaLabel) {
                case 1:
                    this.jLabel3.setVisible(true);
                    this.paint(this.getGraphics());
                    break;
                case 2:
                    this.jLabel1.setVisible(true);
                    this.paint(this.getGraphics());
                    break;
                case 3:
                    this.jLabel2.setVisible(true);
                    this.paint(this.getGraphics());
                    break;
                case 4:
                    Perdiste lose= new Perdiste();
                    lose.setVisible(true);
                    this.paint(this.getGraphics());
                    metodos.imprimir("Te he ahorcado", "lose", 70, 70);
                    
                    
                    try {
                        Thread.sleep(5000);
                        lose.dispose();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(VentanaAhorcado.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;                    
            }
        } else {
            System.out.println("palabraOculta = " + String.valueOf(palabraOculta));
            System.out.println("palabraActiva = " + String.valueOf(palabraActiva));
            if (String.valueOf(palabraOculta).trim().equals(String.valueOf(palabraActiva).trim())) {
                metodos.imprimir("FELICDADES GANASTEEEEEEEE!\n Buen trabajo", "Ganador", 70, 70);
                this.winner.setVisible(true);
                this.felicidades.setVisible(true);
            }
        }
        jTextField2.setText(null);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      
        metodos.imprimir(Pista, "Pista", 70, 70);
        
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void itemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_itemSalirActionPerformed

    private void itemSonidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemSonidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemSonidoActionPerformed

    private void itemReiniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemReiniciarActionPerformed
        ocultarDibujo();
        int contador=1;
        txtTurno.setText("Turno"+(contador+1));
        String Adivinar=JOptionPane.showInputDialog(null, "Palabra a Adivinar", 0);
        Pista=JOptionPane.showInputDialog(null, "Pista de la palabra a Adivinar (Especificar si es mayucusla o minuscula)", 3);
        palabrasAdivinar = new String[5];
        palabrasAdivinar[0] = Adivinar;
        palabraActiva = palabrasAdivinar[0].toCharArray(); // carga la palabra separando caracteres dentro del String
        palabraOculta = palabrasAdivinar[0].toCharArray();// carga la palabra separando caracteres dentro del String
        for (int pos = 0; pos < palabraOculta.length; pos++) {  //cargar un arreglo con guiones q representa la palabra oculta 
            palabraOculta[pos] = '-';
        }
    }//GEN-LAST:event_itemReiniciarActionPerformed

    private void txtPalabraAdivinarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPalabraAdivinarMouseClicked
        
    }//GEN-LAST:event_txtPalabraAdivinarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelAhorcado;
    private javax.swing.JLabel felicidades;
    private javax.swing.JMenuItem itemFondo;
    private javax.swing.JMenuItem itemReiniciar;
    private javax.swing.JMenuItem itemSalir;
    private javax.swing.JMenuItem itemSonido;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JLabel txtPalabraAdivinar;
    private javax.swing.JLabel txtTurno;
    private javax.swing.JLabel winner;
    // End of variables declaration//GEN-END:variables

}
