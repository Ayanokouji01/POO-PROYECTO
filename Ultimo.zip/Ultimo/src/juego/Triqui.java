/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package juego;

import java.applet.AudioClip;
import java.awt.Color;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import Metodos.ventanaFlotante;

public class Triqui extends javax.swing.JInternalFrame {
    ventanaFlotante metodos
            = new ventanaFlotante();
    
    private int ocupados = 0;
    private int Turno = 1;
    private int numPartida = 1;
    AudioClip sonido, sonido2;
    javax.swing.JLabel posciones[] = new javax.swing.JLabel[9];
    private int victoria[][] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9},
        {1, 4, 7},
        {2, 5, 8},
        {3, 6, 9},
        {1, 5, 9},
        {3, 5, 7},};

    public Triqui() {

        setLocation(100, 54);
        initComponents();
        setResizable(false);
        posciones[0] = pos1;
        posciones[1] = pos2;
        posciones[2] = pos3;
        posciones[3] = pos4;
        posciones[4] = pos5;
        posciones[5] = pos6;
        posciones[6] = pos7;
        posciones[7] = pos8;
        posciones[8] = pos9;
        sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Sonidos/L.wav"));
        sonido.play();
        sonido2 = java.applet.Applet.newAudioClip(getClass().getResource("/Sonidos/winteer.wav"));

    }

    public boolean ComprobarValor(javax.swing.JLabel Comprobar) {  //Este metodo valida que no se encintre una 
        switch (Comprobar.getText()) {
            case "X":
                sonido.play();
                metodos.imprimir("No se puede bro esta ocuapo\n ( X )", "Ocupado", 50, 50);
                sonido.play();
                return false;
            case "O":
                sonido.play();
                metodos.imprimir("No se puede bro esta ocuapo\n ( O )", "Ocupado", 50, 50);
                sonido.play();
                return false;

            default:
                
                return true;
        }
    }

    public void DibujarX(javax.swing.JLabel dibujar) {//dibuja X y O
        if (Turno == 1) {
            dibujar.setText("X");
            dibujar.setForeground(Color.WHITE);
            dibujar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/x3.png"))); // NOI18N
            ocupados++;
            Turno = Turno + 1;
        } else {
            dibujar.setText("O");
            dibujar.setForeground(Color.WHITE);
            dibujar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/o2.png"))); // NOI18N
            Turno = Turno - 1;
            ocupados++;
        }
        comprobarGanador();
    }

    public void comprobarGanador() {
        if (ocupados != 9) {
            for (int i = 0; i < victoria.length; i++) {
                if (posciones[victoria[i][0] - 1].getText().equals("X")
                        && posciones[victoria[i][1] - 1].getText().equals("X")
                        && posciones[victoria[i][2] - 1].getText().equals("X")) {
                    sonido2.play();
                    metodos.imprimir("Gandor X\nJugador 1 win", "Ganador", 50, 50);

                    reiniciar();
                }
                if (posciones[victoria[i][0] - 1].getText().equals("O")
                        && posciones[victoria[i][1] - 1].getText().equals("O")
                        && posciones[victoria[i][2] - 1].getText().equals("O")) {
                    sonido2.play();
                    metodos.imprimir("Gandor O\nJugador 2 win", "Ganador", 50, 50);

                    reiniciar();

                }
            }
        }
        else{
            metodos.imprimir("Ha ocurrido un empate", "Empate", 50, 50);
            reiniciar();
        }
    }

    private void reiniciar() {
        for (javax.swing.JLabel poscione : posciones) {
            poscione.setText("");
            poscione.setIcon(null); // NOI18N
            poscione.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
            Turno = 1;
            ocupados=0;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        pos1 = new javax.swing.JLabel();
        pos2 = new javax.swing.JLabel();
        pos3 = new javax.swing.JLabel();
        pos4 = new javax.swing.JLabel();
        pos5 = new javax.swing.JLabel();
        pos6 = new javax.swing.JLabel();
        pos7 = new javax.swing.JLabel();
        pos8 = new javax.swing.JLabel();
        pos9 = new javax.swing.JLabel();
        txtTitulo = new javax.swing.JLabel();
        txtJugador1 = new javax.swing.JLabel();
        txtJugadoor2 = new javax.swing.JLabel();
        txtPartida = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setName("Trqui"); // NOI18N
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jPanel1.setDebugGraphicsOptions(javax.swing.DebugGraphics.BUFFERED_OPTION);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pos1.setBackground(new java.awt.Color(255, 255, 255));
        pos1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos1.setOpaque(true);
        pos1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos1MouseClicked(evt);
            }
        });
        jPanel1.add(pos1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 150, 90));

        pos2.setBackground(new java.awt.Color(255, 255, 255));
        pos2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos2.setOpaque(true);
        pos2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos2MouseClicked(evt);
            }
        });
        jPanel1.add(pos2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, -10, 160, 100));

        pos3.setBackground(new java.awt.Color(255, 255, 255));
        pos3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos3.setOpaque(true);
        pos3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos3MouseClicked(evt);
            }
        });
        jPanel1.add(pos3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, -10, 160, 100));

        pos4.setBackground(new java.awt.Color(255, 255, 255));
        pos4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos4.setOpaque(true);
        pos4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos4MouseClicked(evt);
            }
        });
        jPanel1.add(pos4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 120, 160, 100));

        pos5.setBackground(new java.awt.Color(255, 255, 255));
        pos5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos5.setOpaque(true);
        pos5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos5MouseClicked(evt);
            }
        });
        jPanel1.add(pos5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 160, 100));

        pos6.setBackground(new java.awt.Color(255, 255, 255));
        pos6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos6.setOpaque(true);
        pos6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos6MouseClicked(evt);
            }
        });
        jPanel1.add(pos6, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 120, 160, 100));

        pos7.setBackground(new java.awt.Color(255, 255, 255));
        pos7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos7.setOpaque(true);
        pos7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos7MouseClicked(evt);
            }
        });
        jPanel1.add(pos7, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 250, 160, 100));

        pos8.setBackground(new java.awt.Color(255, 255, 255));
        pos8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos8.setOpaque(true);
        pos8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos8MouseClicked(evt);
            }
        });
        jPanel1.add(pos8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 160, 100));

        pos9.setBackground(new java.awt.Color(255, 255, 255));
        pos9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pos9.setOpaque(true);
        pos9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pos9MouseClicked(evt);
            }
        });
        jPanel1.add(pos9, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 250, 160, 100));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 120, 530, 350));

        txtTitulo.setBackground(new java.awt.Color(51, 0, 0));
        txtTitulo.setFont(new java.awt.Font("Arial Black", 2, 24)); // NOI18N
        txtTitulo.setForeground(new java.awt.Color(102, 102, 102));
        txtTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTitulo.setText("Triqui");
        txtTitulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTituloMouseClicked(evt);
            }
        });
        jPanel2.add(txtTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 160, 50));

        txtJugador1.setForeground(new java.awt.Color(102, 102, 102));
        txtJugador1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtJugador1.setText("Jugador 1");
        jPanel2.add(txtJugador1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, -1, -1));

        txtJugadoor2.setForeground(new java.awt.Color(102, 102, 102));
        txtJugadoor2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtJugadoor2.setText("Jugador 2");
        jPanel2.add(txtJugadoor2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, -1, -1));

        txtPartida.setText("partida:");
        jPanel2.add(txtPartida, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 790, 520));

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pos1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos1MouseClicked
        if (ComprobarValor(pos1) == false) {
            System.out.println("Ocupada");
        } else {

            DibujarX(pos1);
        }
        pos1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_pos1MouseClicked

    private void pos2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos2MouseClicked
        if (ComprobarValor(pos2) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos2);
        }
        pos2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_pos2MouseClicked

    private void pos3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos3MouseClicked

        if (ComprobarValor(pos3) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos3);
        }
        pos3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

    }//GEN-LAST:event_pos3MouseClicked

    private void pos4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos4MouseClicked

        if (ComprobarValor(pos4) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos4);
        }
        pos4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

    }//GEN-LAST:event_pos4MouseClicked

    private void pos5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos5MouseClicked

        if (ComprobarValor(pos5) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos5);
        }
        pos5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

    }//GEN-LAST:event_pos5MouseClicked

    private void pos6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos6MouseClicked

        if (ComprobarValor(pos6) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos6);
        }
        pos6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

    }//GEN-LAST:event_pos6MouseClicked

    private void pos7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos7MouseClicked

        if (ComprobarValor(pos7) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos7);
        }
        pos7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

    }//GEN-LAST:event_pos7MouseClicked

    private void pos8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos8MouseClicked

        if (ComprobarValor(pos8) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos8);
        }
        pos8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

    }//GEN-LAST:event_pos8MouseClicked

    private void pos9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pos9MouseClicked

        if (ComprobarValor(pos9) == false) {
            System.out.println("Ocupada");

        } else {
            DibujarX(pos9);
        }
        pos9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));


    }//GEN-LAST:event_pos9MouseClicked

    private void txtTituloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTituloMouseClicked
       
       
    }//GEN-LAST:event_txtTituloMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel pos1;
    private javax.swing.JLabel pos2;
    private javax.swing.JLabel pos3;
    private javax.swing.JLabel pos4;
    private javax.swing.JLabel pos5;
    private javax.swing.JLabel pos6;
    private javax.swing.JLabel pos7;
    private javax.swing.JLabel pos8;
    private javax.swing.JLabel pos9;
    private javax.swing.JLabel txtJugadoor2;
    private javax.swing.JLabel txtJugador1;
    private javax.swing.JLabel txtPartida;
    private javax.swing.JLabel txtTitulo;
    // End of variables declaration//GEN-END:variables

}
