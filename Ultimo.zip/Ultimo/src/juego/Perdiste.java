/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;
import java.applet.AudioClip;
public class Perdiste extends javax.swing.JFrame {

       AudioClip sonido;
   
    public Perdiste() {
       
        setUndecorated(false);
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
       sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Sonidos/youDied.wav"));
       sonido.play();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lose = new javax.swing.JLabel();
        sayori = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lose.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        lose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gif/lose.gif"))); // NOI18N
        jPanel1.add(lose, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, 420, 650));

        sayori.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/sayori.png"))); // NOI18N
        jPanel1.add(sayori, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, -10, -1, 710));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lose;
    private javax.swing.JLabel sayori;
    // End of variables declaration//GEN-END:variables
}
